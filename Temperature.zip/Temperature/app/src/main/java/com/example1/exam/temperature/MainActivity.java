package com.example1.exam.temperature;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText etID;
    Button btID;
    TextView tvID;
    DecimalFormat formatter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etID=findViewById(R.id.etID);
        btID=findViewById(R.id.btID);
        tvID=findViewById(R.id.tvID);
        tvID.setVisibility(View.GONE);
        formatter= new DecimalFormat("#0.00");

        btID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etID.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Type some number re Bhai", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int no= Integer.parseInt(etID.getText().toString().trim());
                            double tmp= (no/3.0)+4;
                            String s="The approximate ans is:"+formatter.format(tmp)+" ";
                            tvID.setText(s);
                            tvID.setVisibility(View.VISIBLE);

                }

            }
        });
    }
}
